HeritageGate research export

Project ID: demo-structured-001
Schema version: 0.3.0
Project status: completed
Current gate: 7

Contents
--------
manifest.json preserves the complete nested project record.
CSV files provide analysis-ready tables encoded as UTF-8 with BOM for Excel compatibility.
Nested relationships are represented as compact JSON strings in individual CSV cells.
All example records distributed with HeritageGate are synthetic unless explicitly replaced by the user.

Ethics and rights
-----------------
This export does not itself establish permission to share heritage data, personal information,
contracts, model weights, or financial records. Export only records that may lawfully and
ethically leave the controlled project environment.
